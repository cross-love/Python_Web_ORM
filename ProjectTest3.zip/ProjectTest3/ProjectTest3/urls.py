from django.contrib import admin
from django.urls import path, include

# 一级路由配置
urlpatterns = [
    path('admin/', admin.site.urls),
    # 包含应用
    path('', include('AppTest3.urls')),
]
