from django.urls import path, include
from AppTest3.views import *  # 导入应用
from . import views

# 二级路由配置
urlpatterns = [
    path('index/', views.index),
]
