from django.db import models


# Create your models here.
class personal(models.Model):
    name = models.CharField(max_length=32, verbose_name='我的名字')
    hobby = models.CharField(max_length=32, verbose_name='我的爱好')
