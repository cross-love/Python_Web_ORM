from django.shortcuts import render, redirect, HttpResponse
from .models import personal


# Create your views here.

def index(request):
    # 获取对象
    personal_list = personal.objects.all()
    return render(request, 'index.html', {'personal_list': personal_list})
